import React from "react";

const Event1 = () => {
    const handleClick = (e) => {
        console.log(e);
        alert("I was clicked");
    };

    const handleMouseMove = (e) => {
        console.log(e);
        console.log("Hovered");
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        console.log("Form was submitted", e);
    };

    const handleUsernameChanged = (e) => {
        const username = e.target.value;
        console.log(username);
    };

    return (
        <div>
            {/* <button onClick={handleClick} onMouseMove={handleMouseMove}>
                Click Me
            </button> */}

            <form onSubmit={handleFormSubmit}>
                <label htmlFor="name">Name</label>
                <input
                    id="name"
                    type="text"
                    name="username"
                    onChange={handleUsernameChanged}
                />

                <label htmlFor="password">Password</label>
                <input type="password" id="password" name="password" />

                <button onClick={() => alert("Form Submitted")}>Submit</button>
            </form>
        </div>
    );
};

export default Event1;

import React from "react";

const ChildA = (props) => {
    const steps = 5;
    return (
        <button onClick={(e) => props.handler(steps, e)}>Click Me Child A</button>
    );
};

const ChildB = (props) => {
    return (
        <button onClick={(e) => props.handler()}>Click Me Child B</button>
    );
};

const Event2 = () => {
    const walking = (steps, e) => {
        alert("Going for a walk, steps: " + steps);
        e.stopPropagation();
    };

    const eating = () => {
        alert("Eating");
    };

    return (
        <div onClick={() => alert("Clicked from Parent")}>
            <ChildA handler={walking} />
            <ChildB handler={eating} />
        </div>
    );
};

export default Event2;

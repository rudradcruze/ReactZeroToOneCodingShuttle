import React from 'react'
import Counter from './Counter'

const StateSnapshot = () => {
  return (
    <div>
      <Counter />
    </div>
  )
}

export default StateSnapshot
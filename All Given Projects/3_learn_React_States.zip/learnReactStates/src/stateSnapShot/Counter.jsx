import { useState } from "react";

const Counter = () => {
    const [num, setNum] = useState(0);

    async function incrementCounter() {

        setNum(prevNum => prevNum+1);
        setNum(prevNum => prevNum+1);
        setNum(prevNum => prevNum+1);
        setNum((prevNum) => prevNum + 1);
        setNum((prevNum) => prevNum + 1);
        setNum((prevNum) => prevNum + 1);

        // setNum((prevNum) => prevNum + 1); //0+1 = 1
        // // setNum(num+1)
        // // 1st render happens here
        // await new Promise(resolve => setTimeout(resolve, 2000));

        // // setNum(num-1)
        // setNum((prevNum) => prevNum - 1); //1-1 = 0
        
        console.log("num", num);
        // // 2nd render happens here
    }

    console.log("Rendered");

    return (
        <div>
            <p>{num}</p>
            <button onClick={incrementCounter}>Increase Counter</button>
        </div>
    );
};

export default Counter;

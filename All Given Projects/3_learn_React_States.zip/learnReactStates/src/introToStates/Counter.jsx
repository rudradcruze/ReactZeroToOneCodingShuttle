import { useState } from "react";


const Counter = () => {
    const [num, setNum] = useState(0);

    function incrementCounter() {
        setNum(num+1)
        // console.log(counter)
    }

    function decreaseCounter() {
        setNum(num-1);
    }

    console.log("Rendered")

    return (
        <div>
            <p>{num}</p>
            {num>0 && <button onClick={decreaseCounter}>Decrease Counter</button>}
            {num<5 && <button onClick={incrementCounter}>Increase Counter</button>}
        </div>
    );
};

export default Counter;

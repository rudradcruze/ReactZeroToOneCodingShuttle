const ChildB = (props) => {
  return (
    <div>
        <p>Child B Count: {props.data}</p>
    </div>
  )
}

export default ChildB
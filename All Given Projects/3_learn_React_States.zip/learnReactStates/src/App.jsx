import { useState } from "react";
import Event1 from "./eventHandling/Event1";
import Event2 from "./eventHandling/Event2";
import StateIntro from "./introToStates/StateIntro";
import StateSnapshot from "./stateSnapShot/StateSnapshot";
import Parent from "./passingData/Parent";
import TodoPage from "./todos/TodoPage";

const App = () => {

    return (
    <>
       {/* <Parent /> */}

       <TodoPage />
    </>
);
};

export default App;

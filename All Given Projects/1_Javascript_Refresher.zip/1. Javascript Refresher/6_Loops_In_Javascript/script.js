// for (let i = 0; i < 5; i++) {
//     if (i == 2) continue;

//     console.log(i, i * 2, i * 3);
// }

// let i = 0;
// while (i > 10) {
//     console.log(i);
//     i++;
// }

// let i = 0;
// do {
//     console.log(i);
//     i++;
// } while (i > 10);

// const person = {
//     name: "anuj",
//     age: 28,
//     company: "Coding Shuttle",
// };

// for (let property in person) {
//     console.log(property, person[property]);
// }

const a = [1, 3, 5, 7, 8];

for (let val of a) {
    console.log(val);
}

const b = "Apple";

for (let character of b) {
    console.log(character);
}

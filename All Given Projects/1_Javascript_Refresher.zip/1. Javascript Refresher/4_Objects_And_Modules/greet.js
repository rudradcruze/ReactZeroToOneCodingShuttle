function greetings() {
    console.log("Hi there");
}

const PI = 22 / 7;

export function add(a, b) {
    return a + b;
}

export default {
    greetings,
    PI,
    add,
};

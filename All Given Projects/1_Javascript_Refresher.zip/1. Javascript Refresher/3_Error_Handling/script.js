// const a = 4 + 5;

// throw new Error("pass anything, msg");

// // console.log(b);

try {
    const a = 4 + 3;
    console.log(b);
} catch (ex) {
    console.log("Anuj is logging", ex);
} finally {
    console.log("always be executed");
}

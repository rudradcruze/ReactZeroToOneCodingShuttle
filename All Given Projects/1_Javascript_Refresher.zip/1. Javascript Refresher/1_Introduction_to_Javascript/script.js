// let x = "Anuj";
// x = "Shivam";

// for (let i = 0; i < 10; i++) {}

// console.log(x);

// const obj = {
//     name: "Anuj",
//     age: 28,
// };

// console.log(obj.name);

const x = -7;

const y = "-7";

console.log(x === y);

const z = x == -7 ? "hello" : "bye";

console.log(z);

if ("0") {
    console.log("it is true");
} else {
    console.log("it is false");
}

// const y = Number(x);

// console.log(y);

// console.log(typeof y);

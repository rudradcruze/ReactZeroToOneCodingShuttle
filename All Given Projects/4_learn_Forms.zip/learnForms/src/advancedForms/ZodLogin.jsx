import React, { useState } from "react";
import { z, ZodError } from "zod";
import "./LearnZod.js";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

const ZodLogin = () => {
    // const [data, setData] = useState({
    //     email: "",
    //     password: "",
    // });

    // function handleFormSubmit(e) {
    //     e.preventDefault();
    //     try {
    //         const result = zodSchema.parse(data);
    //         console.log(result);
    //         // No more errors are here
    //         setErrors({});
    //     } catch (e) {
    //         if (e instanceof ZodError) {
    //             const newErrors = e.errors.reduce((acc, field) => {
    //                 acc[field.path[0]] = field.message;
    //                 return acc;
    //             }, {});
    //             setErrors(newErrors);
    //             console.log(newErrors);
    //         }
    //     }
    // }

    // function handleInputUpdate(e) {
    //     const { name, value } = e.target;
    //     setData({ ...data, [name]: value });
    // }

    // const [errors, setErrors] = useState({});

    const zodSchema = z.object({
        email: z.string().trim().email("Not a Valid Email Bro"),
        password: z
            .string()
            .trim()
            .min(6, "We need 6 chars at least")
            .max(10, "Not more than 10 chars bro"),
        age: z.number().min(18).optional()
    });

    async function sendToBackend(data) {
        console.log("Sending to backend");

        await new Promise((resolve) => setTimeout(resolve, 3000));

        console.log("Sent", data);
    }

    console.log("Rendering..");

    const {
        register,
        handleSubmit,
        reset,
        watch,
        formState: { isDirty, errors, isSubmitting, isValid },
    } = useForm({
        defaultValues: {
            email: "anuj@gmail.com",
            password: "1234",
        },
        resolver: zodResolver(zodSchema),
        shouldUnregister: true
    });

    console.log(errors);

    const [email, isAdult] = watch(["email", "isAdult"]);

    console.log(email);

    return (
        <div>
            <h1>Zod Login</h1>
            <form onSubmit={handleSubmit(sendToBackend)} noValidate>
                <label>
                    Email
                    <input
                        type="email"
                        {...register("email")}
                        // name="email"
                        // value={data.email}
                        // onChange={handleInputUpdate}
                    />
                </label>
                {errors.email && <p>{errors.email.message}</p>}
                <br />
                <label>
                    Password
                    <input
                        type="password"
                        {...register("password")}
                        // name="password"
                        // value={data.password}
                        // onChange={handleInputUpdate}
                    />
                </label>
                {errors.password && <p>{errors.password.message}</p>}
                <br />

                <label>
                    Are you above 18?
                    <input type="checkbox" {...register("isAdult")} />
                </label>

                <br />
                {isAdult && (
                    <label>
                        Age
                        <input
                            type="number"
                            {...register("age", {valueAsNumber: true})}
                        />
                    </label>
                )}

                <br />

                <button disabled={isSubmitting || !isValid}>Submit</button>
                <button
                    type="button"
                    onClick={() =>
                        reset({
                            email: "",
                            password: "",
                        })
                    }
                >
                    Reset
                </button>
            </form>
        </div>
    );
};

export default ZodLogin;

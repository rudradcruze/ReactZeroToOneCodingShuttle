import { useState } from 'react'
import IntroForm from './introductionToForms/IntroForm'
import SignIn from './dynamicForms/SignIn'
import SignUp from './dynamicForms/SignUp'
import ZodLogin from './advancedForms/ZodLogin'

function App() {

  return (
    // <IntroForm />
    // <SignIn />
    // <SignUp />
    <ZodLogin />
  )
}

export default App

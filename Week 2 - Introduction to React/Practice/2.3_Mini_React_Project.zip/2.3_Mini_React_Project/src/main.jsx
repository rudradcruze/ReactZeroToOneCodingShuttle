import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import reactImg from "./assets/react.svg";
import viteImage from "/vite.svg";
import rightArrow from "./assets/right-arrow.svg";
import Header from "./Header";

import "./profile.css";

createRoot(document.getElementById("root")).render(
	<StrictMode>
		<>
			<Header />
			<header>
				<img
					src={viteImage}
					style={{ width: "4rem", height: "4rem" }}
					alt='vite'
				/>
				<h1 className='heading'>
					Hi, I am a React <span>Developer</span>
				</h1>
			</header>

			<main>
				<h2 className='nameHeading'>
					My name is Francis Rudra D Cruze
				</h2>

				<ol>
					<li>I like React Programming</li>
					<li>I like Vite also, webpack not so much</li>
					<li>Let's build some interactive React Projects!</li>
				</ol>
			</main>

			<a href='#' className='hireMeBtn'>
				<span>Hire Me</span>
				<img src={rightArrow} alt='->' />
			</a>

			<footer style={{ marginTop: "2rem" }}>
				<span style={{ color: "gray" }}>© All rights reserved</span>
			</footer>
		</>
	</StrictMode>
);

import React from "react";

const Footer = () => {
	return (
		<footer style={{ marginTop: "2rem" }}>
			<span style={{ color: "gray" }}>© All rights reserved</span>
		</footer>
	);
};

export default Footer;

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";

const rootElement = document.getElementById("root");
const rootDom = createRoot(rootElement);

const paragraph = (
	<p>
		Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nesciunt
		corrupti provident exercitationem voluptatum eos praesentium at
		consectetur sequi saepe repellat.
	</p>
);

const firstName = "Francis Rudra";
const age = 26;
const lastName = "D Cruze";

const h2Style = {
	color: "white",
	backgroundColor: "tomato",
	padding: "10px",
	borderRadius: "10px",
};

rootDom.render(
	<>
		{lastName && (
			<h1 className='heading name title'>Hello, world! {5 + 5}</h1>
		)}
		<p>Welcome to your new React app.</p>
		{paragraph}
		{age > 25 ? firstName : "You are not old enough"}

		<h2 className='hello' style={h2Style}>
			Hello this is heading 2
		</h2>
	</>
);

// createRoot(document.getElementById("root")).render(
// 	<StrictMode>
// 		<h1>Hello, world!</h1>
// 		<p>Welcome to your new React app.</p>
// 	</StrictMode>
// );

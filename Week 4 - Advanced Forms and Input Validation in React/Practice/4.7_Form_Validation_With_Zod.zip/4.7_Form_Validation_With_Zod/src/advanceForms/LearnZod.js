import { z } from "zod";

const ordersSchema = z.object({
    customer: z.object({
        name: z.string().min(3, "Name is required"),
        email: z.string().email("Invalid email format"),
        password: z
            .string()
            .min(6, "Password must be at least 6 characters")
            .max(10, "Password must be at most 10 characters")
            .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
            .regex(/[a-z]/, "Password must contain at least one lowercase letter")
            .regex(/[0-9]/, "Password must contain at least one number")
            .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
    }),
    id: z.number().min(1000).positive("ID must be a positive number"),
    date: z.date().optional().nullable(),
    price: z.number().positive("Price must be a positive number"),
    category: z.string().refine((value) => {
        if (value === "ORANGE") return false;
        return true;
    }, {
        message: "Category cannot be ORANGE",
    }),
    quantity: z.number().optional().default(1),
});


const ordersData = {
    customer: {
        name: "Mr Rudra",
        email: "francisrudra@gmail.com",
        password: "Abc@123",
    },
    id: 1323,
    // date: new Date("2014-10-10"),
    date: null,
    price: 100.23,
    // category: "ORANGE",
    category: "BANANA",

}

const data = ordersSchema.parse(ordersData);

console.log(data);
import React, { useState } from "react";
import { set, z } from "zod";
import "./LearnZod";

function ZodLogin() {
	const [data, setData] = useState({
		email: "",
		password: "",
	});

	const [errors, setErrors] = useState({});

	const zodSchema = z.object({
		email: z.string().trim().email("Invalid email format"),
		password: z
			.string()
			.trim()
			.min(6, "We need 6 chars at least.")
			.max(10, "We need 10 chars at most."),
	});

	function handleInputUpdate(e) {
		const { name, value } = e.target;
		setData((prevData) => ({
			...prevData,
			[name]: value,
		}));
	}

	function handleFormSubmit(e) {
		e.preventDefault();
		try {
			const result = zodSchema.parse(data);
			console.log("Validation successful:", result);
			setErrors({});
		} catch (error) {
			if (error instanceof z.ZodError) {
				const newErrors = error.errors.reduce((acc, field) => {
					acc[field.path[0]] = field.message;
					return acc;
				}, {});
				setErrors(newErrors);
			} else {
				console.error("Unexpected error:", error);
			}
		}
	}

	return (
		<div>
			<h1>Zod Login</h1>
			<form onSubmit={handleFormSubmit} noValidate>
				<label>
					Email
					<input
						type='email'
						name='email'
						value={data.email}
						onChange={handleInputUpdate}
					/>
				</label>
				{errors.email && <p style={{ color: "red" }}>{errors.email}</p>}
				<br />
				<label>
					Password
					<input
						type='password'
						name='password'
						value={data.password}
						onChange={handleInputUpdate}
					/>
				</label>
				{errors.password && (
					<p style={{ color: "red" }}>{errors.password}</p>
				)}
				<br />
				<button type='submit'>Login</button>
			</form>
		</div>
	);
}

export default ZodLogin;

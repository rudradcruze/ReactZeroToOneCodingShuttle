import React, { useState } from "react";
import { set, z } from "zod";
import "./LearnZod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

function ZodLogin() {
	// const [data, setData] = useState({
	// 	email: "",
	// 	password: "",
	// });

	// function handleFormSubmit(e) {
	// 	e.preventDefault();
	// 	try {
	// 		const result = zodSchema.parse(data);
	// 		console.log("Validation successful:", result);
	// 		setErrors({});
	// 	} catch (error) {
	// 		if (error instanceof z.ZodError) {
	// 			const newErrors = error.errors.reduce((acc, field) => {
	// 				acc[field.path[0]] = field.message;
	// 				return acc;
	// 			}, {});
	// 			setErrors(newErrors);
	// 		} else {
	// 			console.error("Unexpected error:", error);
	// 		}
	// 	}
	// }

	// function handleInputUpdate(e) {
	// 	const { name, value } = e.target;
	// 	setData((prevData) => ({
	// 		...prevData,
	// 		[name]: value,
	// 	}));
	// }

	// const [errors, setErrors] = useState({});

	const zodSchema = z.object({
		email: z.string().trim().email("Invalid email format"),
		password: z
			.string()
			.trim()
			.min(6, "We need 6 chars at least.")
			.max(10, "We need 10 chars at most."),
		age: z.number().min(18).optional(),
	});

	async function sendToBackend(data) {
		console.log("Sending to backend...");

		await new Promise((resolve) => setTimeout(resolve, 3000));

		console.log("Backend Data:", data);
	}

	const {
		register,
		handleSubmit,
		reset,
		watch,
		formState: { isDirty, errors, isSubmitting, isValid },
	} = useForm({
		defaultValues: {
			email: "francisrudra@gmail.com",
			password: "123",
		},
		resolver: zodResolver(zodSchema),
		shouldUnregister: true,
	});

	const [email, isAdult] = watch(["email", "isAdult"]);

	return (
		<div>
			<h1>Zod Login</h1>
			<form onSubmit={handleSubmit(sendToBackend)} noValidate>
				<label>
					Email
					<input
						type='email'
						name='email'
						{...register("email")}
						// value={data.email}
						// onChange={handleInputUpdate}
					/>
				</label>
				{errors.email && (
					<p style={{ color: "red" }}>{errors.email.message}</p>
				)}
				<br />
				<label>
					Password
					<input
						type='password'
						name='password'
						{...register("password")}
						// value={data.password}
						// onChange={handleInputUpdate}
					/>
				</label>
				{errors.password && (
					<p style={{ color: "red" }}>{errors.password.message}</p>
				)}
				<br />

				<label>
					Are you above 18?
					<input type='checkbox' {...register("isAdult")} />
				</label>
				<br />

				{isAdult && (
					<label>
						Age
						<input
							type='number'
							{...register("age", { valueAsNumber: true })}
						/>
					</label>
				)}

				<br />

				<button disabled={!isDirty || isSubmitting || !isValid}>
					{isSubmitting ? "Submitting..." : "Submit"}
				</button>
				<button
					type='button'
					onClick={() =>
						reset({
							email: "",
							password: "",
						})
					}>
					Reset
				</button>
			</form>
		</div>
	);
}

export default ZodLogin;

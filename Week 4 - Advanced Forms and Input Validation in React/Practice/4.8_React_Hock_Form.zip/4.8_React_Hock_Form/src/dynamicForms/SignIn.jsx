import CustomForm from "./CustomForm";
import { SIGN_IN_FORM_CONFIG } from "./formConfig";

function SignIn() {
	function handleSubmit(data) {
		console.log("Data from custom from: ", data);
	}

	return (
		<>
			<h1>Sign In</h1>
			<CustomForm config={SIGN_IN_FORM_CONFIG} onSubmit={handleSubmit} />
		</>
	);
}

export default SignIn;

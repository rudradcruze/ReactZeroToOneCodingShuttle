import ZodLogin from "./advanceForms/ZodLogin";
import SignIn from "./dynamicForms/SignIn";
import SignUp from "./dynamicForms/SignUp";

function App() {
	return (
		<>
			{/* <SignIn /> */}
			{/* <SignUp /> */}
			<ZodLogin />
		</>
	);
}

export default App;

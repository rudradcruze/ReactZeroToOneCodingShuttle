import SignIn from "./dynamicForms/SignIn";

function App() {
	return (
		<>
			<SignIn />
		</>
	);
}

export default App;

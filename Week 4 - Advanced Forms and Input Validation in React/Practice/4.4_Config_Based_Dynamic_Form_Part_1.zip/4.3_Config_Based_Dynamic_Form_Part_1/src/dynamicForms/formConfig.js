export const SIGN_IN_FORM_CONFIG = [
	{
		id: "username",
		name: "username",
		label: "Username",
		placeholder: "e.g. rudradcruze",
		defaultValue: "rudradcruze",
		type: "text"
	},
	{
		id: "email",
		name: "email",
		label: "Email",
		placeholder: "e.g. francisrudra@gmail.com",
		type: "email"
	},
	{
		id: "password",
		name: "password",
		label: "Password",
		placeholder: "Password",
		type: "password"
	},
];


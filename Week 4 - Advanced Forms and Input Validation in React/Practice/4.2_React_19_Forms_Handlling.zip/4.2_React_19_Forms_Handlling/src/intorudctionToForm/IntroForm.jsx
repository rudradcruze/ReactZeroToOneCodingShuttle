import { useActionState } from "react";

function IntroForm() {
	const initState = {
		full_name: "Rudra",
		email: "rudra16-563@diu.edu.bd",
		password: "123",
		country: "bangladesh",
		hobbies: ["reading", "writing"],
		gender: "male",
	};

	const [state, action, isPending] = useActionState(handleForm, initState);

	async function handleForm(prevData, formData) {
		console.log("Prev Data: ", prevData);
		console.log("Submitting...");

		await new Promise((resolve) => setTimeout(resolve, 3000));

		let data = Object.fromEntries(formData);
		const hobbies = formData.getAll("hobbies");
		data = { ...data, hobbies: hobbies ? hobbies : [] };

		console.log("Submitted Successfully!");
		console.log(data);
		return {};
	}

	function handleInputUpdate(event) {
		const { name, value } = event.target;
		console.log(name, value);
	}

	return (
		<form action={action}>
			{/* <label htmlFor='name'>Name</label>
			<input type='text' id='name' placeholder='Name' /> */}

			<label>
				Name
				<input
					disabled={isPending}
					type='text'
					placeholder='Full name'
					name='full_name'
					defaultValue={state.full_name}
				/>
			</label>
			<br />
			{/* <input type='color' name='' id='' /> */}
			{/* <input type='range' name='' min={5} max={10} id='' /> */}

			<label>
				Email
				<input
					disabled={isPending}
					type='email'
					name='email'
					placeholder='Email'
					defaultValue={state.email}
				/>
			</label>
			<br />
			<label>
				Password
				<input
					disabled={isPending}
					type='password'
					name='password'
					placeholder='Password'
					defaultValue={state.password}
				/>
			</label>
			<br />
			<label>
				Gender:
				<label htmlFor='male'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"male"}
						id='male'
						defaultChecked={"male" === state.gender}
					/>
					Male
				</label>
				<label htmlFor='female'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"female"}
						id='female'
						defaultChecked={"female" === state.gender}
					/>
					Female
				</label>
				<label htmlFor='other'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"other"}
						id='other'
						defaultChecked={"others" === state.gender}
					/>
					Other
				</label>
			</label>
			<br />
			<label>
				Country
				<select
					disabled={isPending}
					name='country'
					defaultValue={state.country}>
					<option value=''>Select Country</option>
					<option value='bangladesh'>Bangladesh</option>
					<option value='nepal'>Nepal</option>
					<option value='india'>India</option>
					<option value='china'>China</option>
					<option value='usa'>USA</option>
				</select>
			</label>
			<br />
			<label>
				Hobbies
				<label htmlFor='reading'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='reading'
						id='reading'
						defaultChecked={state.hobbies?.includes("reading")}
					/>
					Reading
				</label>
				<label htmlFor='writing'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='writing'
						id='writing'
						defaultChecked={state.hobbies?.includes("writing")}
					/>
					Writing
				</label>
				<label htmlFor='coding'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='coding'
						id='coding'
						defaultChecked={state.hobbies?.includes("coding")}
					/>
					Coding
				</label>
			</label>
			<br />
			<br />
			<button disabled={isPending}>Submit</button>
			<button type='reset'>Cancle</button>
		</form>
	);
}

export default IntroForm;

export const SIGN_IN_FORM_CONFIG = [
	{
		id: "username",
		name: "username",
		label: "Username",
		placeholder: "e.g. rudradcruze",
		defaultValue: "rudradcruze",
		type: "text"
	},
	{
		id: "email",
		name: "email",
		label: "Email",
		placeholder: "e.g. francisrudra@gmail.com",
		type: "email"
	},
	{
		id: "password",
		name: "password",
		label: "Password",
		placeholder: "Password",
		type: "password"
	},
];

export const SIGN_UP_FORM_CONFIG = [
	{
		id: "name",
		name: "name",
		label: "Name",
		placeholder: "e.g. Francis Rudra D Cruze",
		defaultValue: "",
		type: "text"
	},
	{
		id: "email",
		name: "email",
		label: "Email",
		placeholder: "e.g. francisrudra@gmail.com",
		type: "email"
	},
	{
		id: "password",
		name: "password",
		label: "Password",
		placeholder: "e.g. Strong Password",
		type: "password"
	},
	{
		id: "confirmPassword",
		name: "confirmPassword",
		label: "Confirm Password",
		placeholder: "e.g. same as above password",
		type: "password"
	},
	{
		id: "gender",
		name: "gender",
		label: "Gender",
		placeholder: "",
		type: "radio",
		options: [
			{
				label: "Male",
				value: "male"
			},
			{
				label: "Female",
				value: "female"
			},
			{
				label: "Others",
				value: "others"
			}
		]
	},
	{
		id: "country",
		name: "country",
		label: "Country",
		placeholder: "",
		type: "select",
		options: [
			{
				label: "Bangladesh",
				value: "bangladesh"
			},
			{
				label: "USA",
				value: "usa"
			},
			{
				label: "Canada",
				value: "canada",
			}
		]
	},
	{
		id: "hobbies",
		name: "hobbies",
		label: "Hobbies",
		placeholder: "",
		type: "checkbox",
		options: [
			{
				label: "Sports",
				value: "sports"
			},
			{
				label: "Reading",
				value: "reading"
			},
			{
				label: "Coding",
				value: "coding",
			}
		]
	},
];


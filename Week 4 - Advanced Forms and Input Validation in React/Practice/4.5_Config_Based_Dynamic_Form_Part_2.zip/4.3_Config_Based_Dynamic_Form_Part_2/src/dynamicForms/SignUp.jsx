import React from "react";
import CustomForm from "./CustomForm";
import { SIGN_UP_FORM_CONFIG } from "./formConfig";

function SignUp() {
	function handleSubmit(data) {
		console.log(data);
	}

	return (
		<div>
			<h1>Sign Up From</h1>
			<CustomForm config={SIGN_UP_FORM_CONFIG} onSubmit={handleSubmit} />
		</div>
	);
}

export default SignUp;

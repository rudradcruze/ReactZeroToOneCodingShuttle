import React, { useState } from "react";

import FormInput from "./FormInput";

function CustomForm({ config, onSubmit }) {
	const initData = config.reduce((acc, input) => {
		acc[input.name] = input.defaultValue || "";
		return acc;
	}, {});

	// console.log(initData);

	const [data, setData] = useState(initData);

	function handleInputUpdate(e) {
		const { name, value } = e.target;
		setData({ ...data, [name]: value });
		// console.log(data);
	}

	function handleFromSubmit(e) {
		e.preventDefault();
		onSubmit(data);
		// setData(initData);
	}

	return (
		<form onSubmit={handleFromSubmit}>
			{config.map((input) => (
				<FormInput
					key={input.id}
					value={data[input.name]}
					onChange={handleInputUpdate}
					{...input}
				/>
			))}
			<button type='submit'>Submit</button>
			<button type='reset'>Cancle</button>
		</form>
	);
}

export default CustomForm;

function IntroForm() {
	function handleForm(formData) {
		let data = Object.fromEntries(formData);
		const hobbies = formData.getAll("hobbies");
		data = { ...data, hobbies: hobbies ? hobbies : [] };
		console.log(data);
	}

	function handleInputUpdate(event) {
		const { name, value } = event.target;
		console.log(name, value);
	}

	return (
		<form action={handleForm}>
			{/* <label htmlFor='name'>Name</label>
			<input type='text' id='name' placeholder='Name' /> */}

			<label>
				Name
				<input type='text' placeholder='Full name' name='full_name' />
			</label>
			<br />
			{/* <input type='color' name='' id='' /> */}
			{/* <input type='range' name='' min={5} max={10} id='' /> */}

			<label>
				Email
				<input type='email' name='email' placeholder='Email' />
			</label>
			<br />
			<label>
				Password
				<input type='password' name='password' placeholder='Password' />
			</label>
			<br />
			<label>
				Gender:
				<label htmlFor='male'>
					<input
						type='radio'
						name='gender'
						value={"male"}
						id='male'
					/>
					Male
				</label>
				<label htmlFor='female'>
					<input
						type='radio'
						name='gender'
						value={"female"}
						id='female'
					/>
					Female
				</label>
				<label htmlFor='other'>
					<input
						type='radio'
						name='gender'
						value={"other"}
						id='other'
					/>
					Other
				</label>
			</label>
			<br />
			<label>
				Country
				<select name='country'>
					<option value=''>Select Country</option>
					<option value='bangladesh'>Bangladesh</option>
					<option value='nepal'>Nepal</option>
					<option value='india'>India</option>
					<option value='china'>China</option>
					<option value='usa'>USA</option>
				</select>
			</label>
			<br />
			<label>
				Hobbies
				<label htmlFor='reading'>
					<input
						type='checkbox'
						name='hobbies'
						value='reading'
						id='reading'
					/>
					Reading
				</label>
				<label htmlFor='writing'>
					<input
						type='checkbox'
						name='hobbies'
						value='writing'
						id='writing'
					/>
					Writing
				</label>
				<label htmlFor='coding'>
					<input
						type='checkbox'
						name='hobbies'
						value='coding'
						id='coding'
					/>
					Coding
				</label>
			</label>
			<br />
			<br />
			<button>Submit</button>
			<button type='reset'>Cancle</button>
		</form>
	);
}

export default IntroForm;

import IntroForm from "./intorudctionToForm/IntroForm";

function App() {
	return (
		<>
			<IntroForm />
		</>
	);
}

export default App;

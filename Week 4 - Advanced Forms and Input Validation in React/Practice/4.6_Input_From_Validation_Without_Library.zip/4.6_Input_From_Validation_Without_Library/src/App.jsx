import SignIn from "./dynamicForms/SignIn";
import SignUp from "./dynamicForms/SignUp";

function App() {
	return (
		<>
			{/* <SignIn /> */}
			<SignUp />
		</>
	);
}

export default App;

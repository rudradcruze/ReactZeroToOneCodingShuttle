import { useActionState, useState } from "react";

function IntroForm() {
	const initState = {
		full_name: "Rudra",
		email: "rudra16-563@diu.edu.bd",
		password: "123",
		country: "bangladesh",
		hobbies: ["reading", "writing"],
		gender: "male",
	};

	const [state, action, isPending] = useActionState(handleForm, initState);

	async function handleForm(prevData, formData) {
		console.log("Prev Data: ", prevData);
		console.log("Submitting...");

		await new Promise((resolve) => setTimeout(resolve, 3000));

		let data = Object.fromEntries(formData);
		const hobbies = formData.getAll("hobbies");
		data = { ...data, hobbies: hobbies ? hobbies : [] };

		console.log("Submitted Successfully!");
		console.log(data);
		return {};
	}

	const emptyState = {
		full_name: "",
		email: "",
		password: "",
		country: "",
		gender: "",
		hobbies: [],
	};

	const [data, setData] = useState(emptyState);

	function handleInputUpdate(event) {
		const { name, value, type, checked } = event.target;
		let newData = { ...data, [name]: value };

		if (type === "checkbox") {
			const newHobbies = checked
				? [...data.hobbies, value]
				: data.hobbies.filter((hobby) => hobby !== value);
			newData = { ...data, hobbies: newHobbies };
		}

		setData(newData);
	}

	function onFromSubmit(event) {
		event.preventDefault();
		console.log("Form Submitted!");
		console.log(data);
		setData(emptyState);
	}

	return (
		<form onSubmit={onFromSubmit}>
			{/* <label htmlFor='name'>Name</label>
			<input type='text' id='name' placeholder='Name' /> */}

			<label>
				Name
				<input
					disabled={isPending}
					type='text'
					placeholder='Full name'
					name='full_name'
					value={data.full_name}
					onChange={handleInputUpdate}
				/>
			</label>
			<br />
			{/* <input type='color' name='' id='' /> */}
			{/* <input type='range' name='' min={5} max={10} id='' /> */}

			<label>
				Email
				<input
					disabled={isPending}
					type='email'
					name='email'
					placeholder='Email'
					value={data.email}
					onChange={handleInputUpdate}
				/>
			</label>
			<br />
			<label>
				Password
				<input
					disabled={isPending}
					type='password'
					name='password'
					placeholder='Password'
					value={data.password}
					onChange={handleInputUpdate}
				/>
			</label>
			<br />
			<label>
				Gender:
				<label htmlFor='male'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"male"}
						id='male'
						checked={"male" === data.gender}
						onChange={handleInputUpdate}
					/>
					Male
				</label>
				<label htmlFor='female'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"female"}
						id='female'
						checked={"female" === data.gender}
						onChange={handleInputUpdate}
					/>
					Female
				</label>
				<label htmlFor='other'>
					<input
						disabled={isPending}
						type='radio'
						name='gender'
						value={"other"}
						id='other'
						checked={"other" === data.gender}
						onChange={handleInputUpdate}
					/>
					Other
				</label>
			</label>
			<br />
			<label>
				Country
				<select
					disabled={isPending}
					name='country'
					value={data.country}
					onChange={handleInputUpdate}>
					<option value=''>Select Country</option>
					<option value='bangladesh'>Bangladesh</option>
					<option value='nepal'>Nepal</option>
					<option value='india'>India</option>
					<option value='china'>China</option>
					<option value='usa'>USA</option>
				</select>
			</label>
			<br />
			<label>
				Hobbies
				<label htmlFor='reading'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='reading'
						id='reading'
						checked={data.hobbies.includes("reading")}
						onChange={handleInputUpdate}
					/>
					Reading
				</label>
				<label htmlFor='writing'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='writing'
						id='writing'
						checked={data.hobbies.includes("writing")}
						onChange={handleInputUpdate}
					/>
					Writing
				</label>
				<label htmlFor='coding'>
					<input
						disabled={isPending}
						type='checkbox'
						name='hobbies'
						value='coding'
						id='coding'
						checked={data.hobbies.includes("coding")}
						onChange={handleInputUpdate}
					/>
					Coding
				</label>
			</label>
			<br />
			<br />
			<button disabled={isPending}>Submit</button>
			<button type='reset'>Cancle</button>
		</form>
	);
}

export default IntroForm;

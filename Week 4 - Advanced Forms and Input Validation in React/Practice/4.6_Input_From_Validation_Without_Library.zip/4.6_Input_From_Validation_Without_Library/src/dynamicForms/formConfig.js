export const SIGN_IN_FORM_CONFIG = [
	{
		id: "username",
		name: "username",
		label: "Username",
		placeholder: "e.g. rudradcruze",
		defaultValue: "rudradcruze",
		type: "text"
	},
	{
		id: "email",
		name: "email",
		label: "Email",
		placeholder: "e.g. francisrudra@gmail.com",
		type: "email"
	},
	{
		id: "password",
		name: "password",
		label: "Password",
		placeholder: "Password",
		type: "password"
	},
];

export const SIGN_UP_FORM_CONFIG = [
	{
		id: "name",
		name: "name",
		label: "Name",
		placeholder: "e.g. Francis Rudra D Cruze",
		defaultValue: "",
		type: "text",
		validate: (val) => {
			if (!val) return "Username is required";
			if (val.length < 4) return "Username must be at least 4 length";
			return null;
		}
	},
	{
		id: "email",
		name: "email",
		label: "Email",
		placeholder: "e.g. francisrudra@gmail.com",
		type: "email",
		validate: (val) => {
			if (!val) return "Email is required";
			if (!/\S+@\S+\.\S+/.test(val)) return "Email is invalid";
			return null;
		}
	},
	{
		id: "password",
		name: "password",
		label: "Password",
		placeholder: "e.g. Strong Password",
		type: "password",
		validate: (val) => {
			if (!val) return "Password is required";
			if (val.length < 6) return "Password must be at least 6 length";
			if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/.test(val)) return "Password must contain at least 1 small letter, 1 capital letter, 1 number, 1 special character";
			return null;
		},
	},
	{
		id: "confirmPassword",
		name: "confirmPassword",
		label: "Confirm Password",
		placeholder: "e.g. same as above password",
		type: "password",
		validate: (val, data) => {
			if (!val) return "Confirm Password is required";
			if (val !== data.password) return "Password and Confirm Password must be same";
			return null;
		}
	},
	{
		id: "gender",
		name: "gender",
		label: "Gender",
		placeholder: "",
		type: "radio",
		options: [
			{
				label: "Male",
				value: "male"
			},
			{
				label: "Female",
				value: "female"
			},
			{
				label: "Others",
				value: "others"
			}
		],
		validate: (val) => {
			if (val) return null;
			return "Please select a Gender";
		}
	},
	{
		id: "country",
		name: "country",
		label: "Country",
		placeholder: "",
		type: "select",
		options: [
			{
				label: "Bangladesh",
				value: "bangladesh"
			},
			{
				label: "USA",
				value: "usa"
			},
			{
				label: "Canada",
				value: "canada",
			}
		],
		validate: (val) => {
			if (val) return null;
			return "Please select a country";
		}
	},
	{
		id: "hobbies",
		name: "hobbies",
		label: "Hobbies",
		placeholder: "",
		type: "checkbox",
		options: [
			{
				label: "Sports",
				value: "sports"
			},
			{
				label: "Reading",
				value: "reading"
			},
			{
				label: "Coding",
				value: "coding",
			}
		],
		validate: (val) => {
			if (val && val.length > 0) return null;
			return "Please select at least one hobby";
		}
	},
];


import React, { useState } from "react";

import FormInput from "./FormInput";

function CustomForm({ config, onSubmit, isPending }) {
	const [errors, setErrors] = useState({});

	const initData = config.reduce((acc, input) => {
		acc[input.name] = input.defaultValue || "";
		return acc;
	}, {});

	// console.log(initData);

	const [data, setData] = useState(initData);

	function handleInputUpdate(e) {
		const { name, value } = e.target;
		setData({ ...data, [name]: value });

		const field = config.find((item) => item.name === name);
		if (field && field.validate) {
			const error = field.validate(value);
			setErrors({ ...errors, [name]: error });
		} else {
			setErrors({ ...errors, [name]: null });
		}

		// console.log(data);
	}

	function handleFormSubmit(e) {
		e.preventDefault();

		const newErrors = {};

		config.forEach((item) => {
			const name = item.name;
			const value = data[name];
			const error = item.validate && item.validate(value, data);

			if (error) {
				newErrors[name] = error;
			}
		});

		setErrors(newErrors);

		if (Object.keys(newErrors).length === 0) {
			onSubmit(data);
		} else {
			console.log("Error: ", newErrors);
		}
	}

	return (
		<form onSubmit={handleFormSubmit}>
			{config.map((input) => (
				<FormInput
					key={input.id}
					value={data[input.name]}
					onChange={handleInputUpdate}
					{...input}
					error={errors[input.name]}
				/>
			))}
			<button type='submit' disabled={isPending}>
				{isPending ? "Submitting..." : "Submit"}
			</button>
		</form>
	);
}

export default CustomForm;

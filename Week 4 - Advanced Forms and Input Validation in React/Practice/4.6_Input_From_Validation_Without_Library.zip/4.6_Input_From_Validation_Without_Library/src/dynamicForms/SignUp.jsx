import React, { useState } from "react";
import CustomForm from "./CustomForm";
import { SIGN_UP_FORM_CONFIG } from "./formConfig";

function SignUp() {
	const [isPending, setIsPending] = useState(false);

	async function handleSubmit(data) {
		setIsPending(true);
		await new Promise((resolve) => setTimeout(resolve, 2000));
		setIsPending(false);
		console.log("Data from custom from: ", data);
	}

	return (
		<div>
			<h1>Sign Up From</h1>
			<CustomForm
				config={SIGN_UP_FORM_CONFIG}
				onSubmit={handleSubmit}
				isPending={isPending}
			/>
		</div>
	);
}

export default SignUp;

import Counter from "./Counter";

function StateSnapshot() {
	return (
		<div>
			<h1>State Snapshot</h1>
			<Counter />
		</div>
	);
}

export default StateSnapshot;

import React, { useState } from "react";
import ChildA from "./ChildA";
import ChildB from "./ChildB";

function Parent() {
	const [countParent, setCountParent] = useState(0);

	function handleChildButtonClick(data) {
		setCountParent((previousCount) => previousCount + 1);
	}

	return (
		<div>
			<p>Inside Parent: {countParent}</p>
			{/* <button onClick={handleChildButtonClick}>Parent Click</button> */}
			<ChildA
				count={countParent}
				handleChildButtonClick={handleChildButtonClick}
			/>
			<ChildB data={countParent} />
		</div>
	);
}

export default Parent;

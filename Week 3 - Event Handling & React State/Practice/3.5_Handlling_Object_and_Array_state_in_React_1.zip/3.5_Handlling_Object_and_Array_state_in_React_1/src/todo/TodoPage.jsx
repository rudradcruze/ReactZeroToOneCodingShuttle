import { useState } from "react";
import TodoItem from "./TodoItem";

function TodoPage() {
	// const [person, setPerson] = useState({
	// 	name: "John",
	// 	age: 30,
	// });

	// function handleIncreaseAge() {
	// 	setPerson({
	// 		...person,
	// 		age: person.age + 1,
	// 	});
	// }

	const [todos, setTodos] = useState([]);

	function handleFromSubmit(e) {
		e.preventDefault();
		const todoText = e.target.todo.value;

		// todos.push(todoText);
		setTodos([
			...todos,
			{
				text: todoText,
				id: crypto.randomUUID(),
				isCompleted: false,
			},
		]);

		e.target.reset();
	}

	function onTodoDelete(id) {
		const newTodos = todos.filter((todo) => todo.id !== id);
		setTodos(newTodos);
	}

	const emptyState = <h2>Nothing's Here, Add a Todo</h2>;

	function onTodoToggle(id, cheked) {
		console.log(id, cheked);
		const newTodos = todos.map((todo) => {
			if (todo.id === id) {
				return {
					...todo,
					isCompleted: cheked,
				};
			}

			return todo;
		});
		setTodos(newTodos);
	}

	return (
		<div>
			<h1>Todo Page</h1>
			<form onSubmit={handleFromSubmit}>
				<input
					type='text'
					name='todo'
					placeholder='Enter the todo here...'
				/>
				<button type='submit'>Add Todo</button>
			</form>

			{todos.length === 0 ? (
				emptyState
			) : (
				<div>
					{todos.map((todo) => (
						<TodoItem
							todo={todo}
							key={todo.id}
							onTodoToggle={onTodoToggle}
							onTodoDelete={onTodoDelete}
						/>
					))}
				</div>
			)}
		</div>
	);
}

export default TodoPage;

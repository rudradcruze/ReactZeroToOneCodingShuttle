const TodoItem = ({ todo, onTodoToggle, onTodoDelete }) => {
	return (
		<>
			<div key={todo.id}>
				<input
					id={todo.id}
					checked={todo.isCompleted}
					type='checkbox'
					onChange={(e) => onTodoToggle(todo.id, e.target.checked)}
				/>
				<label
					style={{
						textDecoration: todo.isCompleted
							? "line-through"
							: "none",
					}}
					htmlFor={todo.id}>
					{todo.text}
				</label>

				<button onClick={() => onTodoDelete(todo.id)}>delete</button>
			</div>
		</>
	);
};

export default TodoItem;

import Event1 from "./eventHadlling/Event1";
import Event2 from "./eventHadlling/Event2";

function App() {
	return <Event2 />;
}

export default App;

import { useState } from "react";
import TodoItem from "./TodoItem";
import { Plus, Trash } from "lucide-react";

function TodoPage() {
	const [todos, setTodos] = useState([]);

	// Function to handle form submission and add a new todo
	function handleFromSubmit(e) {
		e.preventDefault();
		const todoText = e.target.todo.value;
		setTodos([
			...todos,
			{
				text: todoText,
				id: crypto.randomUUID(),
				isCompleted: false,
			},
		]);
		e.target.reset();
	}

	// Function to delete a todo
	function onTodoDelete(id) {
		const newTodos = todos.filter((todo) => todo.id !== id);
		setTodos(newTodos);
	}

	// Function to toggle the completion status of a todo
	function onTodoToggle(id, checked) {
		const newTodos = todos.map((todo) =>
			todo.id === id ? { ...todo, isCompleted: checked } : todo
		);
		setTodos(newTodos);
	}

	// Function to move a todo up in the list
	function moveUp(id) {
		const index = todos.findIndex((todo) => todo.id === id);
		if (index > 0) {
			const newTodos = [...todos];
			[newTodos[index - 1], newTodos[index]] = [
				newTodos[index],
				newTodos[index - 1],
			];
			setTodos(newTodos);
		}
	}

	// Function to move a todo down in the list
	function moveDown(id) {
		const index = todos.findIndex((todo) => todo.id === id);
		if (index < todos.length - 1) {
			const newTodos = [...todos];
			[newTodos[index + 1], newTodos[index]] = [
				newTodos[index],
				newTodos[index + 1],
			];
			setTodos(newTodos);
		}
	}

	// Function to delete all todos
	function handleAllDelete() {
		setTodos([]);
	}

	// Function to sort todos
	function handleSortTodos() {
		const newTodos = [...todos];
		newTodos.sort((a, b) => a.text.localeCompare(b.text));
		setTodos(newTodos);
	}

	// Empty state message
	const emptyState = <h2>Nothing's Here, Add a Todo</h2>;

	const isSorted = todos.every((todo, index, arr) => {
		return index === 0 || todo.text >= arr[index - 1].text;
	});

	return (
		<div className='max-w-2xl mx-auto p-10 space-y-6'>
			<h1 className='text-center font-display text-6xl font-bold text-accent'>
				Todo Page
			</h1>
			<p className='text-center text-lg font-light text-secondary-text italic'>
				Manage your Todo with Ease
			</p>
			<form
				className='bg-gray-700 px-6 py-4 rounded-lg flex justify-between gap-4'
				onSubmit={handleFromSubmit}>
				<input
					type='text'
					name='todo'
					placeholder='Enter the todo here...'
					className='flex-1 font-body focus:outline-none'
				/>
				<button
					type='submit'
					className='p-3 bg-accent text-black rounded-lg cursor-pointer hover:bg-accent-hover transition-all duration-150'>
					<Plus />
				</button>
			</form>
			<div className='flex justify-center gap-6'>
				{todos.length > 0 && (
					<button
						className='px-4 py-2 ring-2 ring-red-400 rounded-lg flex gap-2 hover:bg-red-400 hover:text-white transition-all duration-150 cursor-pointer'
						onClick={handleAllDelete}>
						<Trash />
						Delete All
					</button>
				)}
			</div>
			{todos.length === 0 ? (
				emptyState
			) : (
				<div>
					{todos.map((todo, index) => (
						<TodoItem
							todo={todo}
							key={todo.id}
							onTodoToggle={onTodoToggle}
							onTodoDelete={onTodoDelete}
							moveUp={() => moveUp(todo.id)}
							moveDown={() => moveDown(todo.id)}
							index={index}
							todosCount={todos.length}
						/>
					))}
				</div>
			)}
		</div>
	);
}

export default TodoPage;

import {
	Check,
	ChevronDown,
	ChevronUp,
	Pencil,
	Square,
	SquareCheck,
	Trash2,
} from "lucide-react";
import { useState } from "react";

const TodoItem = ({
	todo,
	onTodoToggle,
	onTodoDelete,
	moveUp,
	moveDown,
	index,
	todosCount,
}) => {
	const [isEditing, setIsEditing] = useState(false);

	const handleEditFormSubmit = (e) => {
		e.preventDefault();
		const newTodoText = e.target.todo.value.trim();
		if (newTodoText) {
			onTodoUpdate(todo.id, newTodoText);
			setIsEditing(false);
		}
	};

	return (
		<div className='group flex items-center justify-between gap-4 border-t border-gray-600 px-4 py-2 hover:bg-gray-900'>
			{/* Move buttons */}
			<div className='flex flex-col gap-1 text-gray-400'>
				<button
					className='rounded-md p-1 hover:bg-gray-700'
					onClick={moveUp}
					disabled={index === 0}>
					<ChevronUp size={16} />
				</button>
				<button
					className='rounded-md p-1 hover:bg-gray-700'
					onClick={moveDown}
					disabled={index === todosCount - 1}>
					<ChevronDown size={16} />
				</button>
			</div>

			{/* Todo content */}
			<form
				className='flex flex-1 items-center gap-4'
				onSubmit={handleEditFormSubmit}>
				{/* Checkbox */}
				<button
					type='button'
					onClick={() => onTodoToggle(todo.id, !todo.isCompleted)}
					className='ml-2 text-gray-400 hover:text-white'>
					{todo.isCompleted ? (
						<SquareCheck className='text-green-400' />
					) : (
						<Square />
					)}
				</button>

				{/* Enhanced Editable input */}
				<input
					id={todo.id}
					type='text'
					name='todo'
					required
					defaultValue={todo.text}
					readOnly={!isEditing}
					className={`flex-1 rounded px-2 py-1 transition-all duration-200 ${
						isEditing
							? "cursor-text border-2 border-blue-400 bg-gray-800 text-white ring-1 ring-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400"
							: "cursor-default border-none bg-transparent"
					} ${
						todo.isCompleted && !isEditing
							? "line-through opacity-75"
							: "opacity-100"
					}`}
				/>
			</form>

			{/* Action buttons */}
			<div className='flex gap-2 opacity-0 transition-opacity group-hover:opacity-100'>
				<button
					onClick={() => setIsEditing(!isEditing)}
					className={`transition-colors ${
						isEditing
							? "text-blue-400 hover:text-blue-300"
							: "text-gray-400 hover:text-white"
					}`}>
					{isEditing ? <Check size={18} /> : <Pencil size={18} />}
				</button>
				<button
					onClick={() => onTodoDelete(todo.id)}
					className='text-red-400 hover:text-red-300'>
					<Trash2 size={18} />
				</button>
			</div>
		</div>
	);
};

export default TodoItem;

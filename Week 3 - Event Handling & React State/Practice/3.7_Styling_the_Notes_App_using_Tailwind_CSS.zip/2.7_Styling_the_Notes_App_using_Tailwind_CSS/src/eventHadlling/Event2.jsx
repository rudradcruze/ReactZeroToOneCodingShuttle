import React from "react";

const ChildA = (props) => {
	const steps = 10;
	return (
		<button
			onClick={(e) => {
				props.handler(steps, e);
			}}>
			Click Me from childA
		</button>
	);
};

const ChildB = (props) => {
	return (
		<button
			onClick={(e) => {
				props.handler(e);
			}}>
			Click Me from childB
		</button>
	);
};

function Event2() {
	const walking = (steps, e) => {
		alert("Goding for a walk: " + steps);
		e.stopPropagation();
	};

	const eating = (e) => {
		alert("Eating");
		e.stopPropagation();
	};

	return (
		<>
			<div onClick={() => alert("Parent Div")}>
				<ChildA handler={walking} />
				<ChildB handler={eating} />
			</div>
		</>
	);
}

export default Event2;

import React, { useState } from "react";

function ChildA(props) {
	function handleChildButtonClick() {
		props.handleChildButtonClick();
	}

	return (
		<div>
			<p>Child A Count: {props.count}</p>
			<button onClick={handleChildButtonClick}>Child A Click</button>
		</div>
	);
}

export default ChildA;

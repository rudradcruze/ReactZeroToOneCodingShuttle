import { useState } from "react";

function Counter() {
	const [counter, setCounter] = useState(0);

	// async function increment() {
	// 	setCounter(counter + 1);

	// 	await new Promise((resolve) => setTimeout(resolve, 2000));

	// 	setCounter(counter - 1);
	// }

	// async function increment() {
	// 	setCounter((prevCounter) => prevCounter + 1);

	// 	await new Promise((resolve) => setTimeout(resolve, 2000));

	// 	setCounter((prevCounter) => prevCounter - 1);
	// }

	async function increment() {
		setCounter(counter + 1);

		await new Promise((resolve) => setTimeout(resolve, 2000));

		setCounter(counter - 1);
	}

	const decrement = () => {
		if (counter <= 0) {
			return;
		}
		setCounter(counter - 1);
	};

	return (
		<div>
			<h2>State Snapshot Counter</h2>
			<p>{counter}</p>
			<button onClick={increment}>Increment</button>
			<button onClick={decrement}>Decrement</button>
		</div>
	);
}

export default Counter;

import Event1 from "./eventHadlling/Event1";
import Event2 from "./eventHadlling/Event2";
import Counter from "./intoToStates/Counter";
import StateIntro from "./intoToStates/StateIntro";

function App() {
	return (
		<>
			<StateIntro />
		</>
	);
}

export default App;

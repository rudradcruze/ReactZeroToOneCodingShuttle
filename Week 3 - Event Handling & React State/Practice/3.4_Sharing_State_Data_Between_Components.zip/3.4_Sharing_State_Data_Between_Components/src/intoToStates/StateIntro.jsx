import { useState } from "react";
import Counter from "./Counter";

function StateIntro() {
	const [showCounter, setShowCounter] = useState(true);

	return (
		<>
			{showCounter && <Counter />}

			<button onClick={() => setShowCounter(!showCounter)}>
				Toggle Counter
			</button>
		</>
	);
}

export default StateIntro;

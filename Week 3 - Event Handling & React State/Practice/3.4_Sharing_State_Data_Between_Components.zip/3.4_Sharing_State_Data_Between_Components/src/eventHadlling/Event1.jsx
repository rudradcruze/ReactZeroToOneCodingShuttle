function Event1() {
	const handelClick = () => {
		alert("Hello World");
	};

	const handelMouseMove = (e) => {
		console.log("Mouse is moving");
	};

	const handelFromSubmit = (e) => {
		e.preventDefault();
		const formData = new FormData(e.target);
		const userName = formData.get("userName");
		const userEmail = formData.get("userEmail");
		const userPassword = formData.get("userPassword");
		console.log(userName, userEmail, userPassword);
	};

	const handleUserNameChange = (e) => {
		console.log(e.target.value);
	};

	return (
		<div>
			{/* <button onClick={handelClick} onMouseMove={handelMouseMove}>
				Click Me
			</button> */}

			<form onSubmit={handelFromSubmit}>
				<label htmlFor='name'>Name</label>
				<input
					type='text'
					id='name'
					name='userName'
					onChange={handleUserNameChange}
				/>

				<label htmlFor='email'>Email</label>
				<input type='email' id='email' name='userEmail' />

				<label htmlFor='password'>Password</label>
				<input type='password' id='password' name='userPassword' />

				<button type='submit'>Submit</button>
			</form>
		</div>
	);
}

export default Event1;

import Event1 from "./eventHadlling/Event1";
import Event2 from "./eventHadlling/Event2";
import Counter from "./intoToStates/Counter";
import StateIntro from "./intoToStates/StateIntro";
import Parent from "./passingData/Parent";
import StateSnapshot from "./stateSnapShot/StateSnapshot";

function App() {
	return (
		<>
			<Parent />
		</>
	);
}

export default App;
